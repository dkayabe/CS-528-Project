# CS-528-Project
Semester Project w/ Elizabeth Aquino and William Om-Feld
Contains the repository of the modified neural network smart contract vulnerability detector (improved the accuracy of the detection) as well as a convolutional neural network (CNN).

1. GraphDeeSmartContractFiles - the modified neural network.
2. CNN.py - a CNN but as no vulnerability detection capabilities.
